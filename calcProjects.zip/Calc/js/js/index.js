/*
 ███▄    █  ▄████▄  
 ██ ▀█   █ ▒██▀ ▀█  
▓██  ▀█ ██▒▒▓█    ▄ the javaScript side
▓██▒  ▐▌██▒▒▓▓▄ ▄██▒
▒██░   ▓██░▒ ▓███▀ ░
░ ▒░   ▒ ▒ ░ ░▒ ▒  ░
░ ░░   ░ ▒░  ░  ▒   
   ░   ░ ░ ░        
         ░ ░ ░      
           ░        
*/
alert("thank for viewing of my code! ")
function limitLenght(){
  var afficher= document.querySelector("input.afficher");
  afficher.size = 10;
  afficher.maxLegth =10;
}

function keys(digit){
  var afficher = document.querySelector(".afficher");
  limitLenght()
  afficher.value +=digit;
}

// Function  for ckearing the screen

function clearAfficher() {
  var afficher = document.querySelector(".afficher");
  afficher.value = "";
}

// function for resultat

function resultat(){

  var afficher= document.querySelector(".afficher");
  try{
    if (afficher.value === ""){
      afficher.innerHTML = "";
    }else{
      afficher.value = eval(afficher.value);
    }
  }
  catch(Error){
    afficher.innerHTML = "";
  }
}
var sqr = function() {var afficher= document.querySelector(".afficher");
  afficher.value = afficher.value **2;
}
var exp = function() { var afficher= document.querySelector(".afficher");
  afficher.value = afficher.value * afficher.value;
}
